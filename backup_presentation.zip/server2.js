const ioHook = require('iohook');
 
ioHook.on("mousemove", event => {
  console.log(event);
  /* You get object like this
    {
      type: 'mousemove',
      x: 700,
      y: 400
    }
   */
});
 
//Register and start hook 
ioHook.start();