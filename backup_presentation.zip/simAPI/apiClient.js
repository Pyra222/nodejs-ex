/* global require */
var net = require('net');

var client = net.connect(0x29A, function() { //'connect' listener
    console.log('Client connected');
    client.write('Hello, I\'m client.');
});

client.on('data', function(data) {
    console.log(data.toString());
});

client.on('end', function() {
    console.log('client disconnected');
});
/* exported sendQuery */
function sendQuery(funcName, parameters){
    var delimeter = ';';
    var payLoadArray = [];
    payLoadArray.push(funcName);
    for(var i=0;i<parameters.length;i++){
        payLoadArray.push(parameters[i]);
    }
    var payload = payLoadArray.join(delimeter);
    client.write(payload);
}

/* global process */
var readline = require('readline');

var rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
/* jshint esnext: true */
rl.question('> ', function(input){
    var funcName = input.substring(0,input.indexOf('('));
    console.log(`Function name: ${funcName}`);
    input = input.substring(input.indexOf('(')+1,input.length-1);
    var parameters = input.split(',');
    for(var i=0;i<parameters.length;i++){
        parameters[i] = parameters[i].trim();
    }
    console.log(`${parameters.length} parameter(s): ${parameters}`);
    sendQuery(funcName, parameters);
});