/* global require */

var PORT = 0x29A;
var net = require('net');

var server = net.createServer(function(c) { //'connection' listener
    console.log('server connected');
    c.on('end', function() {
        console.log('server disconnected');
    });
    
    c.on('data', function(data){
        console.log('received: '+data.toString()); 
        c.write("Command received");
    });
});

server.listen(PORT, function() { //'listening' listener
  console.log('Server started at '+PORT);
});