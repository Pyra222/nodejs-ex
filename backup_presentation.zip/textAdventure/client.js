/* Put JSHint options here */
/* global require, process */
/* jshint esnext: true */
var net = require('net');

var readline = require('readline');

var rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.setPrompt('> ',2);

rl.on('line', (input) => {
    client.write(input);
});


var client = net.connect(0x29A, function() {
    
});



client.on('data', function(data) {
    process.stdout.write('\033c');
    console.log(data.toString());
    rl.prompt();
});

client.on('end', function() {
    console.log('Your soul wanders an endless maze...');
});