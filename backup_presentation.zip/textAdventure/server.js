/* Put JSHint options here */
/* global require */
/* jshint esnext: true */
var net = require('net');
var colors = require('colors');

/* Server part, where we welcome and serve out lost soul */
var server = net.createServer(function(socket){
    socket.on('end', () => {
        console.log('Lost forever...');
    });
    socket.on('data', (data) => {
        var response = parseInput(data);
        socket.write(response);
    });
});
server.on('connection', (socket) => {
    socket.setEncoding('utf8');
    console.log('Another lost soul came... '.red+socket.remoteAddress);
    socket.write('Welcome lost soul, what are your wishes?\r\n'+
                 '1. Start a new adventure\r\n'+
                 '2. Continue adventure\r\n'+
                 '3. Get me out of here!');
});
server.listen(0x29A, () => {
    console.log("The all-seeing eye is watching you...");
});

function parseInput(input){
    input = input.trim();
    var response = input;
    console.log(input);
    if(input == "map"){
        response = " ---------------------------- \r\n"+
                   "|                            |\r\n"+
                   "|                            |\r\n"+
                   "|                            |\r\n"+
                   "|                            |\r\n"+
                   "|                            |\r\n"+
                   "|                            |\r\n"+
                   "|                            |\r\n"+
                   "|                            |\r\n"+
                   "|                            |\r\n"+
                   " ---------------------------- ";
    }
    return response;
}