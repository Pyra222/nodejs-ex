/* global setTimeout, require */

var express        = require("express");
var modbus         = require("./scripts/modbus.js");
var bodyParser     = require("body-parser");
var app            = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

var client = null;
var currentIpAddress = '192.168.50.24';
var addrList = [];

var dgram = require('dgram');
var multiclient = dgram.createSocket("udp4");
var reconnectingNow = false;

multiclient.on('listening', function(){
    var address = multiclient.address();
    console.log('UDP Client listening on ' + address.address + ':' + address.port);
    multiclient.setBroadcast(true);
    multiclient.addMembership('224.25.25.50');
});

multiclient.on('message', function (message, remote) {   
    if(addrList.indexOf(remote.address) == -1){
        addrList.push(remote.address);
    }
});

multiclient.bind(5134,'192.168.50.10');

Number.prototype.pad = function(size) {
    var s = String(this);
    while (s.length < (size || 2)) {s = "0" + s;}
    return s;
};

app.get('/',function(req,res){
    res.sendfile("public/index.html");
});

app.get('/music',function(req,res){
    res.sendfile("public/music.html");
});

app.get('/getDevices', function(req,res){
    res.end(addrList.toString());
});

app.get('/getTime',function(req,res){
    if(!reconnectingNow){
        try{
            if(client === null){
                client = new modbus.modbusClient(502,'192.168.50.24');
                client.connect();
                res.end("Conencting");
                return;
            }
            else{
                client.readHoldingRegisters(1, 1690, 6);
                setTimeout(function(){
                    var data = client.readResponse();
                    var timeToSend;
                    if(data.length >= 12){
                        timeToSend = data[11].pad(2) + ":" + data[7].pad(2) + ":" + data[3].pad(2)+':'+currentIpAddress;
                    }
                    res.end(timeToSend);
                },100);
            }
        }
        catch(err){
            console.log(err.message);
            res.end("Reconnecting...");
        }
    }
});

app.post('/setTime',function(req,res){
    try{
        if(client === null){
            client = new modbus.modbusClient(502,'192.168.50.24');
            client.connect();
        }
        else{
            var hour   = req.body.hour;
            var minute = req.body.minute;
            var second = req.body.second;

            client.presetMultipleRegisters(1, 1708, [parseInt(second),parseInt(minute),parseInt(hour)]); 
            setTimeout(function(){
                client.presetMultipleRegisters(1, 1698, [1]);
            },100);
        }
    }
    catch(err){
        console.log(err.message);
        res.end("Reconnecting...");
    }
});

app.post('/reconnect',function(req,res){
    reconnectingNow = true;
    try{
        if(client !== null){
            client.disconnect();
            client = null;
            console.log(client);
            console.log("Creating new cilent");
        }
        client = new modbus.modbusClient('502',req.body.address);
        currentIpAddress = req.body.address;
        client.connect();
        console.log("Connecting to: "+req.body.address);
    }
    catch(err){
        reconnectingNow = false;
        res.end("Reconnecting...");
        console.log(err);
    }
    reconnectingNow = false;
});

app.listen(3000,function(){
  console.log("Started on PORT 3000");
});